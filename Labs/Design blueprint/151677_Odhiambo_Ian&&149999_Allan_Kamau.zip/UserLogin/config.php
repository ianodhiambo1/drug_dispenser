<?php

$conn = mysqli_connect('localhost','root','','mydb') or die('connection failed');

?>